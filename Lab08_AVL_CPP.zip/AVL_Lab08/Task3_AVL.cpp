#include <iostream>
#include <algorithm>
using namespace std;

struct Node {
    int data;
    int height;
    Node* left;
    Node* right;
    Node(int x) {
        data = x;
        height = 1;
        left = right = nullptr;
    }
};

int getHeight(Node* root) {
    if (root == nullptr) return 0;
    return root->height;
}

int balance(Node* root) {
    if (root == nullptr) return 0;
    return getHeight(root->left) - getHeight(root->right);
}

void updateHeight(Node* root) {
    root->height = 1 + max(getHeight(root->left), getHeight(root->right));
}

Node* rotateRight(Node* root) {
    Node* temp = root->left;
    Node* t = temp->right;
    temp->right = root;
    root->left = t;
    updateHeight(root);
    updateHeight(temp);
    return temp;
}

Node* rotateLeft(Node* root) {
    Node* temp = root->right;
    Node* t = temp->left;
    temp->left = root;
    root->right = t;
    updateHeight(root);
    updateHeight(temp);
    return temp;
}

Node* fix(Node* root) {
    updateHeight(root);
    int b = balance(root);
    if (b > 1) {
        if (balance(root->left) < 0) root->left = rotateLeft(root->left);
        return rotateRight(root);
    }
    if (b < -1) {
        if (balance(root->right) > 0) root->right = rotateRight(root->right);
        return rotateLeft(root);
    }
    return root;
}

Node* insert(Node* root, int x) {
    if (root == nullptr) return new Node(x);
    if (x < root->data) root->left = insert(root->left, x);
    else if (x > root->data) root->right = insert(root->right, x);
    else return root; // ignore duplicates
    return fix(root);
}

Node* findMin(Node* root) {
    while (root->left != nullptr) root = root->left;
    return root;
}

Node* removeNode(Node* root, int x) {
    if (root == nullptr) return nullptr;
    if (x < root->data) root->left = removeNode(root->left, x);
    else if (x > root->data) root->right = removeNode(root->right, x);
    else {
        if (root->left == nullptr || root->right == nullptr) {
            Node* temp = root->left != nullptr ? root->left : root->right;
            delete root;
            return temp;
        }
        Node* temp = findMin(root->right);
        root->data = temp->data;
        root->right = removeNode(root->right, temp->data);
    }
    return fix(root);
}

void printTree(Node* root, int space = 0) {
    if (root == nullptr) return;
    printTree(root->right, space + 5);
    for (int i = 0; i < space; i++) cout << " ";
    cout << root->data << endl;
    printTree(root->left, space + 5);
}

void topMax(Node* root, int k, int& count) {
    if (root == nullptr || count >= k) return;
    topMax(root->right, k, count);
    if (count < k) {
        cout << root->data << " ";
        count++;
    }
    topMax(root->left, k, count);
}

void topMin(Node* root, int k, int& count) {
    if (root == nullptr || count >= k) return;
    topMin(root->left, k, count);
    if (count < k) {
        cout << root->data << " ";
        count++;
    }
    topMin(root->right, k, count);
}

void clearTree(Node* root) {
    if (root == nullptr) return;
    clearTree(root->left);
    clearTree(root->right);
    delete root;
}

int main() {
    Node* root = nullptr;
    int n, x, k, choice;
    cout << "How many elements? ";
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> x;
        root = insert(root, x);
        cout << "Tree after inserting " << x << ":\n";
        printTree(root);
    }
    cout << "Enter k: ";
    cin >> k;
    cout << "1. Maximum  2. Minimum: ";
    cin >> choice;
    int count = 0;
    cout << "Top k elements: ";
    if (choice == 2) topMin(root, k, count);
    else topMax(root, k, count);
    cout << endl;

    cout << "Deleting top k elements:\n";
    for (int i = 0; i < k && root != nullptr; i++) {
        Node* temp = root;
        if (choice == 2) {
            while (temp->left != nullptr) temp = temp->left;
        } else {
            while (temp->right != nullptr) temp = temp->right;
        }
        int value = temp->data;
        root = removeNode(root, value);
        cout << "After deleting " << value << ":\n";
        printTree(root);
    }
    clearTree(root);
    return 0;
}
