#include <iostream>
#include <queue>
#include <vector>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int x) {
        data = x;
        next = nullptr;
    }
};

struct compare {
    bool operator()(Node* a, Node* b) {
        return a->data > b->data;
    }
};

Node* mergeLists(vector<Node*>& lists) {
    priority_queue<Node*, vector<Node*>, compare> pq;
    for (int i = 0; i < (int)lists.size(); i++) {
        if (lists[i] != nullptr) pq.push(lists[i]);
    }
    Node dummy(0);
    Node* tail = &dummy;
    while (!pq.empty()) {
        Node* temp = pq.top();
        pq.pop();
        if (temp->next != nullptr) pq.push(temp->next);
        tail->next = temp;
        tail = temp;
    }
    tail->next = nullptr;
    return dummy.next;
}

int main() {
    int k;
    cout << "Enter number of lists: ";
    cin >> k;
    if (k < 0) return 0;
    vector<Node*> lists(k, nullptr);
    for (int i = 0; i < k; i++) {
        int n;
        cout << "Enter size of list " << i + 1 << ": ";
        cin >> n;
        Node* tail = nullptr;
        cout << "Enter sorted elements: ";
        for (int j = 0; j < n; j++) {
            int x;
            cin >> x;
            Node* temp = new Node(x);
            if (lists[i] == nullptr) lists[i] = temp;
            else tail->next = temp;
            tail = temp;
        }
    }
    Node* head = mergeLists(lists);
    cout << "Merged list: ";
    while (head != nullptr) {
        cout << head->data << " ";
        Node* temp = head;
        head = head->next;
        delete temp;
    }
    cout << endl;
    return 0;
}
