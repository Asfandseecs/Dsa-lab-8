#include <iostream>
#include <queue>
#include <vector>
#include <string>
using namespace std;

struct Node {
    char ch;
    int freq;
    Node* left;
    Node* right;
    Node(char c, int f) {
        ch = c;
        freq = f;
        left = right = nullptr;
    }
};

struct compare {
    bool operator()(Node* a, Node* b) {
        return a->freq > b->freq;
    }
};

void preorder(Node* root, string code) {
    if (root == nullptr) return;
    if (root->left == nullptr && root->right == nullptr) {
        cout << root->ch << " : " << (code.empty() ? "0" : code) << endl;
        return;
    }
    preorder(root->left, code + "0");
    preorder(root->right, code + "1");
}

void clearTree(Node* root) {
    if (root == nullptr) return;
    clearTree(root->left);
    clearTree(root->right);
    delete root;
}

int main() {
    int n;
    cout << "Enter number of characters: ";
    cin >> n;
    if (n <= 0) return 0;
    priority_queue<Node*, vector<Node*>, compare> pq;
    cout << "Enter character and frequency:\n";
    for (int i = 0; i < n; i++) {
        char c;
        int f;
        cin >> c >> f;
        pq.push(new Node(c, f));
    }
    while (pq.size() > 1) {
        Node* a = pq.top(); pq.pop();
        Node* b = pq.top(); pq.pop();
        Node* temp = new Node('\0', a->freq + b->freq);
        temp->left = a;
        temp->right = b;
        pq.push(temp);
    }
    Node* root = pq.top();
    cout << "Huffman codes in preorder:\n";
    preorder(root, "");
    clearTree(root);
    return 0;
}
